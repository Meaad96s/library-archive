<?php
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);

$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


if(!$db) {
die("Unable to select database");
}
$RegistrationNo= $_POST['RegistrationNo'];
$date= $_POST['date'];
$title = $_POST['title'];

$qry = "INSERT INTO olddocuments VALUES ('','$RegistrationNo','$date' ,'', '$title', '')";

if (empty($RegistrationNo) || empty($date) || empty($title)) 
{
    
    echo "<script> alert('misssing information.');window.location.href='oldDoc.php';</script>";
}
else {
$result=mysqli_query($myConnection,$qry);
if($result)
{
echo "<script> alert('You have successfully added an old document.');window.location.href='oldDoc.php';</script>";
}
}
exit();

?>