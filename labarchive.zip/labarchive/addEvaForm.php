<?php
session_start();


$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);
/*if(!$con) {
die("could not connect to mysql");
}*/
$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


//Select database
//$db= mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>add evaluation</title>
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
<?php

if(!$_SESSION['loggedin']){
	header("location:index.php");
exit();
}
else{
	$name= $_SESSION['username'];
}

?>
</head>
<body>
<div class="menu-wrap">
  <div class="menu">
    <ul>
      <li><a href="index.php" >home</a></li>
      <li><a href="adoption.php">Apply for Adoption</a></li>
      <li><a href="sponsorship.php">Apply for Sponsorship</a></li>
      <li><a href="about.html" >About us </a></li>
    </ul>
  </div>
</div>
<!--------menu wrap ends--------->
<div class="clearing"></div>
<div class="header">
  
</div>
<!--------header wrap ends--------->
<div class="banner">
  
  
</div>
<!--------banner end-------->
<div class="page">
  <div class="primary-col">
    <div class="generic">
      <div class="panel">
        <div class="title">
          <h1>Add new evaluation</h1>
        </div>
         <div class="content">
         
<hr />
<br><br>
<form action="addEva.php" id="reform" name="myform"  method="POST">

<br/><br/>
<label> employee: &nbsp;</label>
<select name ="emp_id">
<?php


$sql = "SELECT * FROM employees";

$result=mysqli_query($myConnection,$sql);
$result2=mysqli_query($myConnection,$sql);
if($result && $result2) {
	$informa = 1;	
	
while($informa = mysqli_fetch_array( $result )){
  
 
 
 echo "  <option>"          .$informa['emp_id']."   ".$informa['Fname']." ".$informa['Lname']."</option> ";
 
}
echo "</select>";
echo "<br><br><label>supervisor &nbsp; <label><select name='sID'>";
while($informat = mysqli_fetch_array( $result2 )){
  
 
 
 echo "  <option>" .$informat['emp_id']."   ".$informat['Fname']." ".$informat['Lname']."</option> ";
 
}
echo "</select> <br><br>";


}
$qry = "SELECT document_id FROM newdocuments";
$qry2 = "select document_id from evaluation";
$result1 = mysqli_query($myConnection,$qry);
$result3 = mysqli_query($myConnection,$qry2);
$items = array();
if($result3){
//foreach($group_membership as $username) 
while($information1 = mysqli_fetch_array( $result3 )){
 $items[] = $information1;
}}

if($result1){
	echo "<label>document:</label> ";
	while($information = mysqli_fetch_array( $result1 )){
		$items2[] = $information1;
		
	//	echo "  <option>" .$information['document_id']."   </option> ";
 
	}

}

function arrdiff($a1, $a2) {
  $res = array();
  foreach($a2 as $a) if (array_search($a, $a1) === false) $res[] = $a;
  return $res;
  }
  
  

echo "<select name='document_id'>";
$res = array_diff($items, $items2);
foreach( $res as $a) {
	echo "  <option> ";
	echo $a['document_id'];
	echo" </option> ";
}





 ?>


</select>

<br><br>
<label>evaluation (between 0 and 5):</label>
  <input type="number" name="quantity" min="0" max="5" value ="0">
<br><br>
<label>status: </label>
<select name="status" id="stat">
       <option>available</option>
       <option>vacation</option>
	   <option>emergency vacation</option>
	   <option>sick leave</option>
	   <option> vacation</option>
	   <option>vacation</option>
	   <option>exam</option>
	   <option>training course</option>
	   <option>on a task</option>
	   <option>mother </option>
	   <option id="other" >other</option> &nbsp;
	   
	  
   </select>&nbsp;
   
  <label> if other state:&nbsp;</label> <input type="text" id="otherT" name="otherstate"/>
   
   <br><br>

  <input type="submit" value="submit" />
  </form>

        </div>
      </div>
    </div>
  </div>
  <!----primary end--->
  <div class="side-bar">
    <div class="search">
       <div class="title">
	  <?php
        print "<h1>Welcome &nbsp;".$name."</h1>";
	?>
	</div>
<form method='post' action='logout.php'>
<div class='button'><input type='submit' value='Log Out'/></div>
</form>
    </div>
    <div class="clearing"></div>
    <div class="panel">
      <div class="title"> <span><img src="images/icon1.jpg" alt="icon" /></span>
        <h1>Go to</h1>
      </div>
      <div class="content">
        <ul>
          <li><a href="admincontrol.php">Admin Control</a></li>
		  <li><a href="register.php">Register </a></li>
          <li><a href="replyrequests.php">Reply to Requests</a></li>
          <li class="-no-border-bottom"><a href="assign.php">Assign orphans to carers</a></li>
        </ul>
      </div>
    </div>
    <div class="clearing"></div>
    <div class="panel mar-top30">
      <div class="title"> <span><img src="images/icon2.jpg" alt="icon" /></span>
        <h1>Curabitur egestas</h1>
      </div>
      <div class="content"> <img src="images/img1.jpg" alt="image" />
        <div class="recentPost"> Phasellus scelerisque enim eget eros accum san eget ullamco <a href="#">More info +</a> </div>
      </div>
      <div class="clearing"></div>
      <div class="content mar-top30"> <img src="images/img2.jpg" alt="image" />
        <div class="recentPost"> Donec nec justo eget felis facilisis fermentum. <a href="#">More info +</a> </div>
      </div>
      <div class="clearing"></div>
      <div class="content mar-top30"> <img src="images/img3.jpg" alt="image" />
        <div class="recentPost"> Aliquam porttitor mauris sit amet orci. Aenean dignissim . <a href="#">More info +</a> </div>
      </div>
    </div>
  </div>
  <!---side-bar-end--->
</div>
<!---page-end--->
<div class="clearing"></div>
<div class="primary-footer">
  <div class="footer-wrap">
    <div class="footer">
      <div class="page">
        <div class="panel mar-right30">
          <div class="title">
            <h1>Pellentesque Sitm</h1>
          </div>
          <div class="content">
            <P>Phasellus scelerisque enim eget eros accumsa
              Quisque euismod est vitae velit lobortis nec vo
              Nullam non erat et nisl mattis mollis in Maecen
              as at ipsum vel eros auctor fau</P>
            <div class="button"><a href="#">MORE INFO</a></div>
          </div>
        </div>
        <div class="panel mar-right30">
          <div class="title">
            <h1>Cras ornare tristique elit</h1>
          </div>
          <div class="content">
            <ul>
              <li><a href="#">Duis quis dolor felis, aliquet blandit lipsum</a></li>
              <li><a href="#">Phasellus sed erat augue, non porta untun</a></li>
              <li><a href="#">Nullam non erat et nisl mattis mollis in unoki</a></li>
              <li class="-no-border-bottom"><a href="#">Maecenas at ipsum vel eros auctor fausino</a></li>
            </ul>
          </div>
        </div>
        <div class="panel">
          <div class="title">
            <h1>Pellentesque Sitm</h1>
          </div>
          <div class="content">
            <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan porttitor</p>
            <div class="button"><a href="#">MORE INFO</a></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright-wrap">
    <div class="panel">
      <div class="content">
        <P>Copyright (c) Takaful. All rights reserved. </P>
        <p>< <a href="#www.alltemplateneeds.com">www.alltemplateneeds.com</a> > Images From: <a href="www.photorack.net">www.photorack.net</a></p>
      </div>
    </div>
  </div>
</div>
<!--primary-footer-end--->
</body>
</html>
