<?php
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);

$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


if(!$db) {
die("Unable to select database");
}

$RegistrationNo= $_POST['RegistrationNo'];
$date= $_POST['Date'];
$Status = $_POST['Status'];
$BarCode = $_POST['BarCode'];
$From_ = $_POST['From_'];
$To_ = $_POST['To_'];
$Document_Type = $_POST['Document_Type'];


if (empty($RegistrationNo)|| empty($date)|| empty($BarCode)||empty($Status)||empty($From_)||empty($To_)||empty($Document_Type)) 
{
    
    echo "<script> alert('misssing information.');window.location.href='addNewDoc.php';</script>";
}

else {
    $qry = "INSERT INTO newdocuments VALUES ('','$RegistrationNo','$date','$BarCode','', '$Status', '$From_','$To_','$Document_Type','')";
    
$result=mysqli_query($myConnection,$qry);
if($result)
{
echo "<script> alert('You have successfully added a new document.');window.location.href='NewDoc.php';</script>";
}
}
exit();

?>