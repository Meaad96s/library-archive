<?php
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);
/*if(!$con) {
die("could not connect to mysql");
}*/
$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


//Select database
//$db= mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}

$document_id= $_GET['document_id'];



$degree = $_GET['degree'];
/*


$last_average = 100;
$total_numbers = 10;
$new_number = 54;

$new_average = (($last_average * $total_numbers) + $new_number) / ($total_number + 1);

*/






$sql = "select * from evaluation WHERE document_id='$document_id'";
$result1=mysqli_query($myConnection,$sql);
if($result1)
{
	$informa = 1;	
	
while($informa = mysqli_fetch_array( $result1 )){
$last_average = $informa['degree'];
$total_numbers = $informa['numOfTimesOfEva'];
$new_number = $degree;

$new_average = (($last_average * $total_numbers) + $new_number) / ($total_numbers + 1);
//fix required how to make value only 5
	  
$date =  date("Y/m/d") ;

$qry = "UPDATE evaluation SET degree='$new_average',date = '$date' WHERE document_id='$document_id'";

$result=mysqli_query($myConnection,$qry);
if($result)
{
echo "<script> alert('You have successfully evaluated an employee.');window.location.href='evaluationform.php';</script>";
exit();
}

else{
echo "<script> alert('no changes have been made.');window.location.href='evaluationform.php';</script>";
exit();}

}}
?>