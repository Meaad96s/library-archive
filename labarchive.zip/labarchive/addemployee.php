<?php
session_start();


$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);
/*if(!$con) {
die("could not connect to mysql");
}*/
$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


//Select database
//$db= mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>addnewemployee</title>
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
<?php

if(!$_SESSION['loggedin']){
	header("location:index.php");
exit();
}
else{
	$name= $_SESSION['username'];
}

?>
</head>
<body>
<div class="menu-wrap">
  <div class="menu">
    <ul>
      <li><a href="index.php" >home</a></li>
      <li><a href="adoption.php">Apply for Adoption</a></li>
      <li><a href="sponsorship.php">Apply for Sponsorship</a></li>
      <li><a href="about.html" >About us </a></li>
    </ul>
  </div>
</div>
<!--------menu wrap ends--------->
<div class="clearing"></div>
<div class="header">
  
</div>
<!--------header wrap ends--------->
<div class="banner">
  
  
</div>
<!--------banner end-------->
<div class="page">
  <div class="primary-col">
    <div class="generic">
      <div class="panel">
        <div class="title">
          <h1>Add new employee</h1>
        </div>
         <div class="content">
         
<hr />
<br><br>
<form action="addnewemp.php" id="reform" name="myform"  method="POST">

<label>first name: </label><input name="Fname" type="text" value="" required/>
<label>&nbsp;&nbsp;&nbsp;last name: </label><input name="Lname" type="text" value="" required/><br/><br/>
<label> employee's id: </label><input name="emp_id" type="number" value="" required/><br><br>

<label> department: </label>

<select name="Department" id="dep">
       <!--<option>classes</option>
       <option>public relations</option>
	   <option>technology</option>
	   <option>Beneficiaries Services</option>
	   <option> branches</option>
	   <option>Financial affairs</option>
	   <option>Personnel</option>
	   <option>Automated reply</option>
	   <option>mother </option>
	   <option id="other" >other</option>-->
<?php 
$sql = "SELECT * FROM departments";

$result=mysqli_query($myConnection,$sql);

if($result) {
	$informa = 1;	
	
while($informa = mysqli_fetch_array( $result )){
  
 
 
 echo "  <option>".$informa['dep_name']."</option> ";
 
}}




?>



	   &nbsp;
	   
	  <option id="other" >other</option>
   </select><label> if other state:&nbsp;</label> <input type="text" id="otherD" name="otherdep"/>

<br><br>
<label>status: </label>
<select name="status" id="stat">
       <option>available</option>
       <option>vacation</option>
	   <option>emergency vacation</option>
	   <option>sick leave</option>
	   <option> vacation</option>
	   <option>vacation</option>
	   <option>exam</option>
	   <option>training course</option>
	   <option>on a task</option>
	   <option>mother </option>
	   <option id="other" >other</option> &nbsp;
	   
	  
   </select>&nbsp;
   
  <label> if other state:&nbsp;</label> <input type="text" id="otherT" name="otherstate"/>
   
   <br><br>

  <input type="submit" value="submit" />
  </form>

        </div>
      </div>
    </div>
  </div>
  <!----primary end--->
  <div class="side-bar">
    <div class="search">
       <div class="title">
	  <?php
        print "<h1>Welcome &nbsp;".$name."</h1>";
	?>
	</div>
<form method='post' action='logout.php'>
<div class='button'><input type='submit' value='Log Out'/></div>
</form>
    </div>
    <div class="clearing"></div>
    <div class="panel">
      <div class="title"> <span><img src="images/icon1.jpg" alt="icon" /></span>
        <h1>Go to</h1>
      </div>
      <div class="content">
        <ul>
          <li><a href="admincontrol.php">Admin Control</a></li>
		  <li><a href="register.php">Register </a></li>
          <li><a href="replyrequests.php">Reply to Requests</a></li>
          <li class="-no-border-bottom"><a href="assign.php">Assign orphans to carers</a></li>
        </ul>
      </div>
    </div>
    <div class="clearing"></div>
    <div class="panel mar-top30">
      <div class="title"> <span><img src="images/icon2.jpg" alt="icon" /></span>
        <h1>Curabitur egestas</h1>
      </div>
      <div class="content"> <img src="images/img1.jpg" alt="image" />
        <div class="recentPost"> Phasellus scelerisque enim eget eros accum san eget ullamco <a href="#">More info +</a> </div>
      </div>
      <div class="clearing"></div>
      <div class="content mar-top30"> <img src="images/img2.jpg" alt="image" />
        <div class="recentPost"> Donec nec justo eget felis facilisis fermentum. <a href="#">More info +</a> </div>
      </div>
      <div class="clearing"></div>
      <div class="content mar-top30"> <img src="images/img3.jpg" alt="image" />
        <div class="recentPost"> Aliquam porttitor mauris sit amet orci. Aenean dignissim . <a href="#">More info +</a> </div>
      </div>
    </div>
  </div>
  <!---side-bar-end--->
</div>
<!---page-end--->
<div class="clearing"></div>
<div class="primary-footer">
  <div class="footer-wrap">
    <div class="footer">
      <div class="page">
        <div class="panel mar-right30">
          <div class="title">
            <h1>Pellentesque Sitm</h1>
          </div>
          <div class="content">
            <P>Phasellus scelerisque enim eget eros accumsa
              Quisque euismod est vitae velit lobortis nec vo
              Nullam non erat et nisl mattis mollis in Maecen
              as at ipsum vel eros auctor fau</P>
            <div class="button"><a href="#">MORE INFO</a></div>
          </div>
        </div>
        <div class="panel mar-right30">
          <div class="title">
            <h1>Cras ornare tristique elit</h1>
          </div>
          <div class="content">
            <ul>
              <li><a href="#">Duis quis dolor felis, aliquet blandit lipsum</a></li>
              <li><a href="#">Phasellus sed erat augue, non porta untun</a></li>
              <li><a href="#">Nullam non erat et nisl mattis mollis in unoki</a></li>
              <li class="-no-border-bottom"><a href="#">Maecenas at ipsum vel eros auctor fausino</a></li>
            </ul>
          </div>
        </div>
        <div class="panel">
          <div class="title">
            <h1>Pellentesque Sitm</h1>
          </div>
          <div class="content">
            <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan porttitor</p>
            <div class="button"><a href="#">MORE INFO</a></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright-wrap">
    <div class="panel">
      <div class="content">
        <P>Copyright (c) Takaful. All rights reserved. </P>
        <p>< <a href="#www.alltemplateneeds.com">www.alltemplateneeds.com</a> > Images From: <a href="www.photorack.net">www.photorack.net</a></p>
      </div>
    </div>
  </div>
</div>
<!--primary-footer-end--->
</body>
</html>
