<?php
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);
/*if(!$con) {
die("could not connect to mysql");
}*/
$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


//Select database
//$db= mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}
$id= $_POST['id'];
$FName= $_POST['Fname'];
$LName= $_POST['Lname'];
$Department=$_POST['Department'];
$status = $_POST['status'];

$qry = "UPDATE employees SET FName='$FName',LName='$LName', Department='$Department',status='$status' WHERE id='$id'";

$result=mysqli_query($myConnection,$qry);
if($result)
{
echo "<script> alert('You have successfully edited an employee.');window.location.href='employeeslistforAdmin.php';</script>";
exit();
}
else
print"we cant edit";

?>