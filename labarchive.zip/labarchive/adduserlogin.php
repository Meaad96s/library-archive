<?php
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);
$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


//Select database
if(!$db) {
die("Unable to select database");
}

$username= $_POST['username'];
$password= $_POST['password'];


$qry = "INSERT INTO employeelogin VALUES (NULL,'$username', '$password')";


$result=mysqli_query($myConnection,$qry);
if($result)
{
echo "<script> alert('You have successfully added a user.');window.location.href='admincpanel.html';</script>";
exit();
}
else
print"we cant add";

?>