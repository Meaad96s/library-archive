<?php

session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);
/*if(!$con) {
die("could not connect to mysql");
}*/
$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


//Select database
//$db= mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}
/*$_SESSION["correctadmin"]= "admin";
$_SESSION["correctadminpass"]= "12345";*/


	$name= $_POST['username'];
  $pass= $_POST['password'];
  $useroradmin = $_POST['useroradmin'];
  
 
  




if($useroradmin==="admin"){
$qry="SELECT * FROM admin";


//$result=mysql_query($qry);
$result=mysqli_query($myConnection,$qry);
$logincorrect = false;
if($result){
while($info = mysqli_fetch_array($result)){
 
if($name==$info['username'] && $pass==$info['password']){

$_SESSION['loggedin']='yes';
$_SESSION['username']= $name;
$logincorrect = true;
header("location:admincpanel.html");
//exit();

//echo "<script> alert('ok');window.location.href='admincpanel.html';</script>";
}}

if($logincorrect===false)
{echo "<script> alert('username and password did not match');window.location.href='loginform.html';</script>";
exit();}

}}
elseif($useroradmin==="employee"){
	
	
$qry="SELECT * FROM employeelogin";

	

//$result=mysql_query($qry);
$result=mysqli_query($myConnection,$qry);
//print "im in the else";
//$sqry="SELECT * FROM carer";
//print "sqry successful";

$logincorrect = false;
//print "found the array";
if($result){	
while($infos = mysqli_fetch_array($result)){
if($name==$infos['username'] && $pass==$infos['password']){
$_SESSION['loggedin']='yes';
$_SESSION['username']= $name;
header("location:emppanel.html");


//echo "<script> alert('ok');window.location.href='emppanel.html';</script>";

$logincorrect = true;




exit();
}
}
if($logincorrect===false)
{echo "<script> alert('username and password did not match');window.location.href='loginform.html';</script>";
exit();}
}
}

/*else if($result1){
$_SESSION['loggedin']='yes';
$_SESSION['username']= $name;
header("location:manage.php");
exit();
}
else { 
echo "<script>
alert('incorrect user name or password');
window.location.href='loginform.php';
</script>";
exit();}*/
 

?>