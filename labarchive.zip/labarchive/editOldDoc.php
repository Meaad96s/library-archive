<?php
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'labarchive'; //DB Name here
//Connect to mysqlserver
$db = new PDO('mysql:host=localhost;dbname=labarchive;charset=utf8mb4', $DB_USER, $DB_PASSWORD);
/*if(!$con) {
die("could not connect to mysql");
}*/
$myConnection= mysqli_connect('localhost','root','', 'labarchive') or die ("could not connect to mysql");


//Select database
//$db= mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}
$id= $_POST['id'];
$RegistrationNo= $_POST['RegistrationNo'];
$date= $_POST['date'];
$title = $_POST['title'];
$lastEditedBy= $_POST['username'];

$sql = "select * from olddocuments WHERE id='$id'";
$result1=mysqli_query($myConnection,$sql);
if($result1)
{
	$informa = 1;	
	
while($informa = mysqli_fetch_array( $result1 )){
if ($RegistrationNo!==$informa['RegistrationNo'] ||$date!== $informa['date'] || $title !== $informa['title']){
	  


$qry = "UPDATE olddocuments SET RegistrationNo='$RegistrationNo',date='$date', title='$title',lastEditedBy='$lastEditedBy' WHERE id='$id'";

$result=mysqli_query($myConnection,$qry);
if($result)
{
echo "<script> alert('You have successfully edited an old document.');window.location.href='oldDoc.php';</script>";
exit();
}
else
print"we cant edit";
}
else{
echo "<script> alert('no changes have been made.');window.location.href='oldDoc.php';</script>";
exit();}

}}
?>